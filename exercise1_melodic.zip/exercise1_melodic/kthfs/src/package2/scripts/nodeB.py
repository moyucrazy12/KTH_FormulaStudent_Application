#!/usr/bin/env python
"""
nodeB: subscribes to /mallqui (Int32) and publishes result to /kthfs/result
at 20 Hz. The result is the latest received value divided by q (q = 0.15).
To minimize bandwidth the publisher uses queue_size=1 and publishes Float32.
"""

import rospy
from std_msgs.msg import Float32, Int32


class NodeB(object):
    """Subscriber that divides incoming k by q and republishes result."""

    def __init__(self):
        rospy.init_node("nodeB_processor", anonymous=False)

        self.input_topic = "/mallqui"
        self.output_topic = "/kthfs/result"
        self.q = 0.15

        # Latest received integer value
        self.latest = None

        # Publisher uses Float32, small queue.
        self.pub = rospy.Publisher(self.output_topic, Float32, queue_size=1)

        # Subscriber receives Int32 on /mallqui.
        rospy.Subscriber(self.input_topic, Int32, self.callback)

        rospy.loginfo("nodeB: subscribed to %s, publishing to %s",
                      self.input_topic, self.output_topic)

    def callback(self, msg):
        """Store the latest received message."""
        self.latest = msg.data

    def run(self):
        """Publish latest/q at 20 Hz. If no message received yet, do nothing."""
        rate = rospy.Rate(20.0)
        while not rospy.is_shutdown():
            if self.latest is not None:
                result = float(self.latest) / self.q
                msg = Float32()
                msg.data = result
                self.pub.publish(msg)
            rate.sleep()


if __name__ == "__main__":
    try:
        node = NodeB()
        node.run()
    except rospy.ROSInterruptException:
        pass

