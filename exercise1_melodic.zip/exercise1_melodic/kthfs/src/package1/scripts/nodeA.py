#!/usr/bin/env python
"""
nodeA: publishes integer k on the global topic /mallqui at 20 Hz.
k starts at 1 and increments by n (n = 4) at each loop.
Queue size is 1 to reduce bandwidth. Message type: std_msgs/Int32.
"""

import rospy
from std_msgs.msg import Int32


def run_publisher():
    """Create a publisher that sends an integer increasing by 4 at 20 Hz."""
    rospy.init_node("nodeA_publisher", anonymous=False)

    topic_name = "/mallqui"
    pub = rospy.Publisher(topic_name, Int32, queue_size=1)

    rate = rospy.Rate(20.0)  # 20 Hz
    n = 4
    k = 1

    rospy.loginfo("nodeA: publishing on %s at 20 Hz", topic_name)

    while not rospy.is_shutdown():
        msg = Int32()
        msg.data = k
        pub.publish(msg)
        k += n
        rate.sleep()


if __name__ == "__main__":
    try:
        run_publisher()
    except rospy.ROSInterruptException:
        pass

