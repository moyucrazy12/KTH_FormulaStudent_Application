#!/usr/bin/env python3
"""
nodeA: publishes integer k on the global topic /mallqui at 20 Hz.
k starts at 1 and increments by n (n = 4) at each loop.
Message type: std_msgs/Int32.
"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32


class NodeAPublisher(Node):
    def __init__(self):
        super().__init__("nodeA_publisher")

        self.topic_name = "/mallqui"
        self.n = 4
        self.k = 1

        # Publisher
        self.pub = self.create_publisher(Int32, self.topic_name, 1)

        # 20 Hz timer
        self.timer = self.create_timer(0.05, self.timer_callback)

        self.get_logger().info(
            f"nodeA: publishing on {self.topic_name} at 20 Hz"
        )

    def timer_callback(self):
        msg = Int32()
        msg.data = self.k
        self.pub.publish(msg)
        self.get_logger().debug(f"Published: {self.k}")
        self.k += self.n


def main(args=None):
    rclpy.init(args=args)
    node = NodeAPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
