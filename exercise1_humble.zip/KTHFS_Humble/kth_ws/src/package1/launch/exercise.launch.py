#!/usr/bin/env python3
"""
Launch file to run:
 - nodeA from package1
 - nodeB from package2
"""

from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        Node(
            package="package1",
            executable="nodeA",
            name="nodeA_publisher",
            output="screen"
        ),
        Node(
            package="package2",
            executable="nodeB",
            name="nodeB_processor",
            output="screen"
        )
    ])

