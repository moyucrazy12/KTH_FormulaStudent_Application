#!/usr/bin/env python3
"""
nodeB: subscribes to /mallqui (Int32) and publishes result to /kthfs/result
at 20 Hz. The result is the latest received value divided by q (q = 0.15).
Publisher uses queue_size=1 and publishes Float32.
"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32, Float32


class NodeBProcessor(Node):
    def __init__(self):
        super().__init__("nodeB_processor")

        self.input_topic = "/mallqui"
        self.output_topic = "/kthfs/result"
        self.q = 0.15
        self.latest = None

        # Publisher
        self.pub = self.create_publisher(Float32, self.output_topic, 1)

        # Subscriber
        self.sub = self.create_subscription(
            Int32, self.input_topic, self.callback, 1
        )

        # 20 Hz timer
        self.timer = self.create_timer(0.05, self.timer_callback)

        self.get_logger().info(
            f"nodeB: subscribed to {self.input_topic}, publishing to {self.output_topic}"
        )

    def callback(self, msg: Int32):
        self.latest = msg.data
        self.get_logger().debug(f"Received: {self.latest}")

    def timer_callback(self):
        if self.latest is not None:
            result = float(self.latest) / self.q
            msg = Float32()
            msg.data = result
            self.pub.publish(msg)
            self.get_logger().debug(f"Published: {result}")


def main(args=None):
    rclpy.init(args=args)
    node = NodeBProcessor()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
